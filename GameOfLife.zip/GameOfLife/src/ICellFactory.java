
public interface ICellFactory {
	
	public ICell Make(Grid parent, int row, int cell, boolean c);

}
