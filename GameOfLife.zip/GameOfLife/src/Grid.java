import java.util.Iterator;

public class Grid implements Iterable<ICell> {
    private ICell[][] board;
    private int rows, cols;

    public Grid(boolean[][] start, ICellFactory cf){
        rows = start.length;
        cols = start.length;
        board = new Cell[rows][cols];
        for(int r = 0; r < rows; r++){
            for(int c = 0; c < cols; c++){
                board[r][c] = cf.Make(this, r, c, start[r][c]);
            }
        }
    }
    public Iterator<ICell> iterator() { return new GridIterator();}
    
    public class GridIterator implements Iterator<ICell>{
        private int r =0;
        private int c = 0;
        public boolean hasNext(){
            return (r < rows) && ( c < cols);
        }
        public ICell next() {
            if (!hasNext()){
                return null;
            }
            ICell cell  = board[r][c];
            c++;
            if(c>=cols){
                c=0;
                r++;
            }
            return cell;
        }
    }

    public ICell CellAt(int row, int col){
        if((row >= 0) && (row < rows) && (col >= 0) && (col < cols)){
            return (board[row][col]);
        }else{
            return null;
        }
    }

    public void OneGen(){
        for(ICell cell : this) cell.determine();
        for(ICell cell : this) cell.update();

    }
    public void Update(int gens) {
        for(int i =0; i<gens; ++i){
            OneGen();
        }
    }
    public boolean[][] State(){
        boolean[][] state = new boolean[rows][cols];
        for (ICell c: this){
            state[c.row()][c.col()] = c.is_alive();
        }

        return state;
    }
}